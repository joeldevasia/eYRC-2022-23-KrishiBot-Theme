#! /usr/bin/env python3

""" 
* Team Id : 2546
* Author List : Joel Devasia
* Filename: percepStack.py
* Theme: Krishi Bot (KB)
* Functions: [ bot_status_updater, img_clbck, depth_clbck, image_processing, tf_broadcaster, get_realWorld_Cordinates, twoD_to_threeD,  main ]
"""

# Initialize Global variables

import cv2
import rospy
from cv_bridge import CvBridge, CvBridgeError
from sensor_msgs.msg import Image, CompressedImage
from std_msgs.msg import String
import numpy as np
import tf
import math
bridge = CvBridge()
pose = []
fruit_red = []
fruit_yellow = []
area_fruit_red = []
area_fruit_yellow = []
depth_val_red = []
depth_val_yellow = []
bot_Status = ""
fx = 554.387
fy = 554.387
cx = 320.5
cy = 240.5

################# ADD UTILITY FUNCTIONS HERE #################


def bot_status_updater(status):
    global bot_Status
    bot_Status = status.data

bot_pub = rospy.Publisher(
    "bot_status", String, queue_size=1, headers={"node": "percepStack.py"}
)
rospy.Subscriber("bot_status", String, bot_status_updater)


def tf_broadcaster(X, Y, Z, fruit, parent):
    """
    * Function Name: tf_broadcaster
    * Input: X, Y, Z, fruit, parent
    * Output: None
    * Logic: Broadcasts the TF of the fruit
    *
    * Example Call: tf_broadcaster(Xy, Yy, Zy, "yellow_bell_pepper", "camera_link")
    """
    rate = rospy.Rate(5)
    br = tf.TransformBroadcaster()
    global bot_Status
    if not math.isnan(X) and not math.isnan(Y) and not math.isnan(Z):
        if Z > 0.4 and Z < 1:

            br.sendTransform(
                (Z, -X, -Y),
                tf.transformations.quaternion_from_euler(0, 0, 0),
                rospy.Time.now(),
                fruit,
                parent,
            )
            bot_pub.publish("stop")
            rate.sleep()

    else:
        a = 1 + 2
        print("X: ", X, "Y: ", Y, "Z: ", Z,
              "fruit: ", fruit, "parent: ", parent)
    print("Depth: ", Z)


def get_realWorld_Cordinates():
    """
    * Function Name: get_realWorld_Cordinates
    * Input: None
    * Output: None
    * Logic: Gets the real world cordinates of the fruit
    *
    * Example Call: get_realWorld_Cordinates()
    """
    global pose
    global fruit_red
    global fruit_yellow
    global depth_val_red
    global depth_val_yellow

    # get yellow fruit cordinates

    try:
        if len(fruit_yellow) != 0:

            Xy, Yy, Zy = twoD_to_threeD(
                fruit_yellow[0][0], fruit_yellow[0][1], depth_val_yellow[0]
            )
            tf_broadcaster(Xy, Yy, Zy, "yellow_bell_pepper", "camera_link")

    except Exception as e:

        print("Error in [YELLOW] get_realWorld_Cordinates: ", e)

    # get red fruit cordinates
    try:
        if len(fruit_red) != 0:

            Xr, Yr, Zr = twoD_to_threeD(
                fruit_red[0][0], fruit_red[0][1], depth_val_red[0]
            )
            tf_broadcaster(Xr, Yr, Zr, "red_bell_pepper", "camera_link")

    except Exception as e:
        print("Error in [RED] get_realWorld_Cordinates", e)


def twoD_to_threeD(x, y, depth):
    """
    * Function Name: twoD_to_threeD
    * Input: x, y, depth
    * Output: X, Y, Z
    * Logic: Converts the 2D cordinates to 3D cordinates
    *
    * Example Call: twoD_to_threeD(x, y, depth)
    """
    X = depth * ((x - cx) / fx)
    Y = depth * ((y - cy) / fy)
    Z = depth
    return X, Y, Z


##############################################################


def img_clbck(img_msg):
    """
    * Function Name: img_clbck
    * Input: img_msg
    * Output: None
    * Logic: Callback function for the image
    *
    * Example Call: img_clbck(img_msg)
    """

    global pub_rgb  # , add global variable if any
    global pose
    global fruit_red
    global fruit_yellow
    global area_fruit_red
    global area_fruit_yellow

    ############################### Add your code here #######################################
    # img_msg is the callback data
    np_arr = np.frombuffer(img_msg.data, np.uint8)
    cv_image = cv2.imdecode(
        np_arr, cv2.IMREAD_COLOR
    )  # cv_image is the cv2 format image
    ##########################################################################################

    fruit_red, fruit_yellow = image_processing(cv_image)
    if len(fruit_red) != 0 or len(fruit_yellow) != 0:
        bot_pub.publish("stop")
        print("perception stack: stop")


def depth_clbck(depth_msg):
    """
    * Function Name: depth_clbck
    * Input: depth_msg
    * Output: None
    * Logic: Callback function for the depth image
    *
    * Example Call: depth_clbck(depth_msg)
    """

    global depth_val_red
    depth_val_red = []
    global depth_val_yellow
    depth_val_yellow = []

    ############################### Add your code here #######################################
    depth = bridge.imgmsg_to_cv2(depth_msg, desired_encoding="passthrough")

    for i in range(len(fruit_red)):
        depth_val_red.append(depth[fruit_red[i][1], fruit_red[i][0]] / 1000)

    for i in range(len(fruit_yellow)):
        depth_val_yellow.append(
            depth[fruit_yellow[i][1], fruit_yellow[i][0]] / 1000)

    ##########################################################################################
    try:
        get_realWorld_Cordinates()
    except:
        print("Error in get_realWorld_Cordinates")
        pass


def image_processing(image):
    """
    * Function Name: image_processing
    * Input: image
    * Output: fruit_red, fruit_yellow
    * Logic: Finds the centroid of the bell peppers
    *
    * Example Call: image_processing(image)
    """

    fruit_red = []
    fruit_yellow = []

    ############### Write Your code to find centroid of the bell peppers #####################
    blur = cv2.GaussianBlur(image, (5, 5), 0)
    hsvImage = cv2.cvtColor(blur, cv2.COLOR_BGR2HSV)
    output = image.copy()

    # yellow_lower = np.array([8, 86, 49], np.uint8)
    # yellow_upper = np.array([16, 228, 255], np.uint8)
    # yellow_lower = np.array([6, 133, 98], np.uint8)
    # yellow_lower = np.array([9, 110, 86], np.uint8)
    # yellow_upper = np.array([16, 219, 255], np.uint8)

    # yellow_lower = np.array([9, 153, 156], np.uint8)
    # yellow_upper = np.array([23, 255, 255], np.uint8)
    yellow_lower = np.array([5, 129, 123], np.uint8)
    yellow_upper = np.array([23, 255, 255], np.uint8)

    # red_lower = np.array([0, 76, 39], np.uint8)
    # red_upper = np.array([14, 219, 225], np.uint8)
    # red_lower = np.array([0, 59, 0], np.uint8)
    # red_upper = np.array([0, 255, 225], np.uint8)

    # red_lower = np.array([165, 148, 124], np.uint8)
    # red_upper = np.array([179, 255, 225], np.uint8)
    red_lower = np.array([154, 99, 85], np.uint8)
    red_upper = np.array([179, 255, 225], np.uint8)

    # Threshold the HSV image to get only yellow colors
    yellow_mask = cv2.inRange(hsvImage, yellow_lower, yellow_upper)
    red_mask = cv2.inRange(hsvImage, red_lower, red_upper)
    newMask = yellow_mask | red_mask

    # define kernel size
    kernel = np.ones((7, 7), np.uint8)

    # Remove unnecessary noise from mask
    newMask = cv2.morphologyEx(newMask, cv2.MORPH_CLOSE, kernel)
    newMask = cv2.morphologyEx(newMask, cv2.MORPH_OPEN, kernel)

    yellow_mask = cv2.morphologyEx(yellow_mask, cv2.MORPH_CLOSE, kernel)
    yellow_mask = cv2.morphologyEx(yellow_mask, cv2.MORPH_OPEN, kernel)
    red_mask = cv2.morphologyEx(red_mask, cv2.MORPH_CLOSE, kernel)
    red_mask = cv2.morphologyEx(red_mask, cv2.MORPH_OPEN, kernel)

    contours_yellow, hierarchy_yellow = cv2.findContours(
        yellow_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )
    contours_red, hierarchy_red = cv2.findContours(
        red_mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
    )

    # loop over the contours
    for c in contours_yellow:
        if cv2.contourArea(c) > 650:
            # compute the center of the contour
            M = cv2.moments(c)
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])

            fruit_yellow.append([cX, cY])
            # draw the contour and center of the shape on the image
            output = cv2.drawContours(image, [c], -1, (0, 255, 0), 2)
            output = cv2.circle(image, (cX, cY), 7, (255, 255, 255), -1)
            output = cv2.putText(
                image,
                "Yellow",
                (cX - 20, cY - 20),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (255, 255, 255),
                2,
            )

    for c in contours_red:
        if cv2.contourArea(c) > 650:
            # compute the center of the contour
            M = cv2.moments(c)
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])

            fruit_red.append([cX, cY])
            # draw the contour and center of the shape on the image
            output = cv2.drawContours(image, [c], -1, (0, 255, 0), 2)
            output = cv2.circle(image, (cX, cY), 7, (255, 255, 255), -1)
            output = cv2.putText(
                image,
                "Red",
                (cX - 20, cY - 20),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.5,
                (255, 255, 255),
                2,
            )

    ##########################################################################################
    cv2.imshow("new mask", output)
    cv2.waitKey(30)
    return fruit_red, fruit_yellow


def main():
    """
    MAIN FUNCTION

    Purpose:
    -----
    Initialize ROS node and do the publish and subscription of data.

    NOTE: We have done the subscription only for one image, you have to iterate over
    three images in the same script and publish the centroid and depth in the
    same script for three images, calling the same callback function.

    """

    #### EDIT YOUR CODE HERE FOR SUBSCRIBING TO OTHER TOPICS AND TO APPLY YOUR ALGORITHM TO PUBLISH #####
    rospy.init_node("percepStack", anonymous=True)
    print("Initialized Perception Stack Script")
    rospy.Subscriber("/camera/color/image_raw/compressed",
                     CompressedImage, img_clbck)
    rospy.Subscriber(
        "/camera/aligned_depth_to_color/image_raw", Image, depth_clbck)
    rospy.spin()
    ####################################################################################################


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print("Error:", str(e))
    finally:
        print("Executed Perception Stack Script")
